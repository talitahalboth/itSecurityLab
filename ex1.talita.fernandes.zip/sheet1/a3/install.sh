apt-get install dsniff libnetfilter-queue-dev python python-pip
pip install netfilterqueue scapy-python3